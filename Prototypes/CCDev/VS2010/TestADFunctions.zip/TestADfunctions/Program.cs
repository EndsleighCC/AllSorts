﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using NetworkDetail;

namespace TestADfunctions
{
    class Program
    {
        static void Main(string[] args)
        {
            string userAccountName = Environment.UserName;

            if (args.Count() > 0)
                userAccountName = args[0];

            NetworkDetail.UserAccessDetail userAccessDetail = new UserAccessDetail();

            string userTechRef = userAccessDetail.UserTechRefFromAccountName(userAccountName);

            Console.WriteLine();
            if (userTechRef != null)
            {
                Console.WriteLine("User \"{0}\" Tech. Ref. is \"{1}\"", userAccountName, userTechRef);
            }
            else
            {
                Console.WriteLine("User \"{0}\" does not have a Tech. Ref.", userAccountName);
            }

            Console.WriteLine();
            Console.WriteLine( "Distinguished Name for Account \"{0}\" is:\n    \"{1}\"",
                                userAccountName,userAccessDetail.DistinguishedNameFromSAMAccountName(userAccountName));

            if (false)
            {
                string groupName = "System Builders";
                Console.WriteLine();
                if (userAccessDetail.UserWithTechRefIsNetworkGroupMember(userTechRef, groupName))
                    Console.WriteLine("Tech. Ref. \"{0}\" for User \"{1}\" is a member of \"{2}\"", userTechRef,
                                      userAccountName, groupName);
                else
                    Console.WriteLine("Tech. Ref. \"{0}\" for User \"{1}\" is NOT a member of \"{2}\"", userTechRef,
                                      userAccountName, groupName);
            }

            Collections.CaseIgnoringSortedSetType networkGroupsForUser = userAccessDetail.NetworkGroupsForUserAccountName(userAccountName);
            Console.WriteLine();
            Console.WriteLine("Network Group Membership");
            Console.WriteLine("~~~~~~~~~~~~~~~~~~~~~~~~");
            foreach (string networkGroupName in networkGroupsForUser)
            {
                Console.WriteLine("    \"{0}\"",networkGroupName);
            }

        }
    }
}
