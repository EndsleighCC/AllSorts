﻿//**********************************************************************
//        COPYRIGHT ENDSLEIGH INSURANCE SERVICES LIMITED 2012
//**********************************************************************
//   PROJECT         :   insurance.net
//   LANGUAGE        :   C#
//   FILENAME        :   Collections.cs
//   ENVIRONMENT     :   Microsoft Visual Studio
//**********************************************************************
//   FILE FUNCTION   :   Useful Collection Classes
//   EXECUTABLE TYPE :   DLL
//   SPECIFICATION   :   None
//
//   RELATED DOCUMENTATION : None
//
//**********************************************************************
//   ABSTRACT        :   Useful Collection Classes
//                       
//   AUTHOR          :   C. Cornelius        CREATION DATE : 18-Sep-2012
//
//**********************************************************************
//   BUILD INFORMATION   :   Endsleigh Build System
//
//**********************************************************************
//   PVCS SECTION:
//   ~~~~~~~~~~~~~
//   PVCS FILENAME: $Logfile:   $
//   PVCS REVISION: $Revision:  $
//
//   $Log$
//
//**********************************************************************

using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;

namespace NetworkDetail
{
    public class Collections
    {
        [Serializable]
        public class CaseIgnoringSortedSetType : SortedSet<string>
        {
            // Construct empty
            public CaseIgnoringSortedSetType()
                : base(StringComparer.CurrentCultureIgnoreCase)
            {
            }

            // Construct and copy from another set
            public CaseIgnoringSortedSetType(CaseIgnoringSortedSetType existingSet)
                : base(existingSet, StringComparer.CurrentCultureIgnoreCase)
            {
            }
            protected CaseIgnoringSortedSetType(SerializationInfo info, StreamingContext context)
                : base(info, context)
            {
            }
        }

        [Serializable]
        public class StringStringIgnoreCaseSortedDictionaryType : SortedDictionary<string, string>
        {
            public StringStringIgnoreCaseSortedDictionaryType()
                : base(StringComparer.CurrentCultureIgnoreCase)
            {
            }
        }
    }
}
